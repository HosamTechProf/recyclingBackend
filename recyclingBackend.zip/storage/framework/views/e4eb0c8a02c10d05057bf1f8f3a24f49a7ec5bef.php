<?php $__env->startSection('content'); ?>

<div class="container">
  <h3>People answer with super</h3>
  <table class="table table-bordered">
    <thead class="thead-dark">
      <tr>
        <th scope="col">Answer 1</th>
        <th scope="col">How much useful and effective was the application?</th>
        <th scope="col">Was it easy to use?</th>
        <th scope="col">How much was this addition useful and easy to use?</th>
        <th scope="col">was there any problem?</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $surveys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $survey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($survey->type === 'Super'): ?>
      <tr>
        <th style="background-color: #212529;color:white" scope="row"><?php echo e($survey->type); ?></th>
        <td><?php echo e($survey->q1); ?></td>
        <td><?php echo e($survey->q2); ?></td>
        <td><?php echo e($survey->q3); ?></td>
        <td><?php echo e($survey->q4); ?></td>
      </tr>
      <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>
<hr>
<br><br>
<hr>
<div class="container">
  <h3>People answer with can be better</h3>
  <table class="table table-bordered">
    <thead class="thead-dark">
      <tr>
        <th scope="col">Answer 1</th>
        <th scope="col">Feedback</th>
        <th scope="col">what can we do to improve?</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $surveys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $survey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($survey->type === 'Can be better'): ?>
      <tr>
        <th style="background-color: #212529;color:white" scope="row"><?php echo e($survey->type); ?></th>
        <th scope="row"><?php echo e($survey->q5); ?></th>
        <th scope="row"><?php echo e($survey->q6); ?></th>
      </tr>
      <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/amr/Development/recycling/recyclingBackend/resources/views/survey/index.blade.php ENDPATH**/ ?>